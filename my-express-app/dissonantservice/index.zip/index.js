const express = require('express');
const app = express();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const bodyParser = require('body-parser');
const serverless = require('serverless-http');
const fetch = require('node-fetch');
const nodemailer = require('nodemailer');
const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
let firebaseApp;
try {
  if (admin.apps.length === 0) {
    firebaseApp = admin.initializeApp({
      credential: admin.credential.applicationDefault(),
      projectId: process.env.FIREBASE_PROJECT_ID || 'dissonantapp2',
    });
  } else {
    firebaseApp = admin.app();
  }
} catch (error) {
  console.log('Firebase Admin already initialized');
  firebaseApp = admin.app();
}

const db = admin.firestore();

app.use(bodyParser.json());

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail', // You can change this to SendGrid, Mailgun, etc.
  auth: {
    user: process.env.EMAIL_USER || 'your-email@gmail.com',
    pass: process.env.EMAIL_PASSWORD || 'your-app-password',
  },
});

app.post('/create-payment-intent', async (req, res) => {
  const { amount } = req.body;

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount,
      currency: 'usd',
    });

    res.send({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// New endpoint: Shippo address validation
app.post('/validate-address', async (req, res) => {
  try {
    const { name, street1, street2, city, state, zip, country = 'US' } = req.body || {};
    if (!street1 || !city || !state || !zip) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const shippoResp = await fetch('https://api.goshippo.com/addresses/?validate=true', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
      body: JSON.stringify({
        ...(name ? { name } : {}),
        street1,
        ...(street2 ? { street2 } : {}),
        city,
        state,
        zip,
        country,
        validate: true,
      }),
    });

    const data = await shippoResp.json();
    if (!shippoResp.ok) {
      return res.status(shippoResp.status).json({ error: 'Shippo error', details: data?.detail || data });
    }

    const isValid = data?.validation_results?.is_valid === true;
    if (!isValid) return res.json({ isValid: false });

    const zipRaw = String(data.zip || '');
    const [zip5, zip4] = zipRaw.split('-');

    return res.json({
      isValid: true,
      address: {
        street: [data.street1, data.street2].filter(Boolean).join(' ').trim(),
        city: data.city,
        state: data.state,
        zip5,
        zip4: zip4 || null,
      },
    });

  } catch (err) {
    console.error('Shippo validate-address error', err);
    return res.status(500).json({ error: 'Internal error' });
  }
});

// PayPal payment endpoint
app.post('/create-paypal-payment', async (req, res) => {
  try {
    const { amount, currency = 'USD', return_url, cancel_url } = req.body || {};
    if (!amount) {
      return res.status(400).json({ error: 'Missing amount' });
    }

    // For now, return a mock PayPal approval URL
    // In a real implementation, you'd integrate with PayPal SDK
    const mockPaymentId = `PAY-${Date.now()}`;
    const approvalUrl = `https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=${mockPaymentId}`;
    
    console.log(`Mock PayPal payment created for $${amount} ${currency}`);
    
    return res.json({
      payment_id: mockPaymentId,
      approval_url: approvalUrl,
      amount,
      currency,
      status: 'created'
    });
  } catch (err) {
    console.error('PayPal payment creation error', err);
    return res.status(500).json({ error: 'Internal error' });
  }
});

// Create shipping labels (outbound + return) via Shippo
app.post('/create-shipping-labels', async (req, res) => {
  try {
    const { to_address, parcel, order_id, customer_name, customer_email } = req.body || {};
    
    if (!to_address || !parcel) {
      return res.status(400).json({ error: 'Missing required address or parcel info' });
    }

    console.log(`Creating shipping labels for order ${order_id}`);

    // Warehouse address (from environment variables)
    const from_address = {
      name: process.env.WAREHOUSE_NAME || 'Dissonant',
      street1: process.env.WAREHOUSE_STREET || '789 9th St APT 4C',
      city: process.env.WAREHOUSE_CITY || 'New York',
      state: process.env.WAREHOUSE_STATE || 'NY',
      zip: process.env.WAREHOUSE_ZIP || '10019',
      country: process.env.WAREHOUSE_COUNTRY || 'US',
    };

    // Create outbound shipment
    console.log('Creating outbound shipment...');
    const outboundShipment = await fetch('https://api.goshippo.com/shipments/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
      body: JSON.stringify({
        address_to: to_address,
        address_from: from_address,
        parcels: [parcel],
        async: false,
      }),
    });

    if (!outboundShipment.ok) {
      const errorData = await outboundShipment.json();
      console.error('Outbound shipment creation failed:', errorData);
      throw new Error(`Failed to create outbound shipment: ${errorData.detail || errorData.message}`);
    }

    const outboundShipmentData = await outboundShipment.json();
    console.log('Outbound shipment created:', outboundShipmentData.object_id);

    // Get rates for outbound shipment
    console.log('Getting outbound rates...');
    const outboundRates = await fetch(`https://api.goshippo.com/shipments/${outboundShipmentData.object_id}/rates/`, {
      headers: {
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
    });

    if (!outboundRates.ok) {
      const errorData = await outboundRates.json();
      console.error('Failed to get outbound rates:', errorData);
      throw new Error(`Failed to get outbound rates: ${errorData.detail || errorData.message}`);
    }

    const outboundRatesData = await outboundRates.json();
    console.log('Available outbound rates:', outboundRatesData.results.map(r => `${r.servicelevel.name} (${r.provider}) - $${r.amount}`));
    
    // Prioritize USPS Ground Advantage for outbound (cheapest option)
    const outboundRate = outboundRatesData.results.find(rate => 
      rate.provider === 'USPS' && rate.servicelevel.name === 'Ground Advantage'
    ) || outboundRatesData.results.find(rate => 
      rate.provider === 'USPS' && rate.servicelevel.name === 'First Class'
    ) || outboundRatesData.results.find(rate => rate.provider === 'USPS') || outboundRatesData.results[0];

    if (!outboundRate) {
      throw new Error('No suitable outbound rate found');
    }
    
    console.log(`Selected outbound rate: ${outboundRate.servicelevel.name} (${outboundRate.provider}) - $${outboundRate.amount}`);
    console.log('Creating 4x6 inch Ground Advantage outbound label...');
    console.log('Selected outbound rate:', outboundRate.object_id);

    // Create outbound transaction (label)
    console.log('Creating outbound label...');
    const outboundTransaction = await fetch('https://api.goshippo.com/transactions/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
      body: JSON.stringify({
        rate: outboundRate.object_id,
        async: false,
        label_file_type: 'PDF_4X6', // 4x6 inch label for easy printing
      }),
    });

    if (!outboundTransaction.ok) {
      const errorData = await outboundTransaction.json();
      console.error('Outbound transaction creation failed:', errorData);
      throw new Error(`Failed to create outbound transaction: ${errorData.detail || errorData.message}`);
    }

    const outboundTransactionData = await outboundTransaction.json();
    console.log('Outbound label created:', outboundTransactionData.object_id);
    
    // Wait a moment for the label to be fully generated
    if (outboundTransactionData.status === 'SUCCESS') {
      console.log('Outbound label status:', outboundTransactionData.status);
      console.log('Outbound label URL:', outboundTransactionData.label_url);
      console.log('Outbound tracking:', outboundTransactionData.tracking_number);
    } else {
      console.log('Outbound label status:', outboundTransactionData.status);
      console.log('Outbound label message:', outboundTransactionData.messages);
    }

    // Create return shipment (reverse addresses)
    console.log('Creating return shipment...');
    const returnShipment = await fetch('https://api.goshippo.com/shipments/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
      body: JSON.stringify({
        address_to: from_address, // Return to warehouse
        address_from: to_address, // From customer
        parcels: [parcel],
        async: false,
      }),
    });

    if (!returnShipment.ok) {
      const errorData = await returnShipment.json();
      console.error('Return shipment creation failed:', errorData);
      throw new Error(`Failed to create return shipment: ${errorData.detail || errorData.message}`);
    }

    const returnShipmentData = await returnShipment.json();
    console.log('Return shipment created:', returnShipmentData.object_id);

    // Get rates for return shipment
    console.log('Getting return rates...');
    const returnRates = await fetch(`https://api.goshippo.com/shipments/${returnShipmentData.object_id}/rates/`, {
      headers: {
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
    });

    if (!returnRates.ok) {
      const errorData = await returnRates.json();
      console.error('Failed to get return rates:', errorData);
      throw new Error(`Failed to get return rates: ${errorData.detail || errorData.message}`);
    }

    const returnRatesData = await returnRates.json();
    console.log('Available return rates:', returnRatesData.results.map(r => `${r.servicelevel.name} (${r.provider}) - $${r.amount}`));
    
    // Prioritize USPS Ground Advantage for returns (cheapest option)
    const returnRate = returnRatesData.results.find(rate => 
      rate.provider === 'USPS' && rate.servicelevel.name === 'Ground Advantage'
    ) || returnRatesData.results.find(rate => 
      rate.provider === 'USPS' && rate.servicelevel.name === 'First Class'
    ) || returnRatesData.results.find(rate => rate.provider === 'USPS') || returnRatesData.results[0];

    if (!returnRate) {
      throw new Error('No suitable return rate found');
    }
    
    console.log(`Selected return rate: ${returnRate.servicelevel.name} (${returnRate.provider}) - $${returnRate.amount}`);
    console.log('Creating 4x6 inch Ground Advantage return label...');
    console.log('Selected return rate:', returnRate.object_id);

    // Create return transaction (label)
    console.log('Creating return label...');
    const returnTransaction = await fetch('https://api.goshippo.com/transactions/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
      body: JSON.stringify({
        rate: returnRate.object_id,
        async: false,
        label_file_type: 'PDF_4X6', // 4x6 inch label for easy printing
      }),
    });

    if (!returnTransaction.ok) {
      const errorData = await returnTransaction.json();
      console.error('Return transaction creation failed:', errorData);
      throw new Error(`Failed to create return transaction: ${errorData.detail || errorData.message}`);
    }

    const returnTransactionData = await returnTransaction.json();
    console.log('Return label created:', returnTransactionData.object_id);
    
    // Wait a moment for the label to be fully generated
    if (returnTransactionData.status === 'SUCCESS') {
      console.log('Return label status:', returnTransactionData.status);
      console.log('Return label URL:', returnTransactionData.label_url);
      console.log('Return tracking:', returnTransactionData.tracking_number);
    } else {
      console.log('Return label status:', returnTransactionData.status);
      console.log('Return label message:', returnTransactionData.messages);
    }

    // Prepare label data for emails
    console.log('Preparing label data...');
    console.log('Outbound transaction data keys:', Object.keys(outboundTransactionData));
    console.log('Return transaction data keys:', Object.keys(returnTransactionData));
    
    // Check if labels were successfully generated
    const outboundLabel = {
      label_url: outboundTransactionData.status === 'SUCCESS' ? outboundTransactionData.label_url : 'Label generation failed - check Shippo dashboard',
      tracking_number: outboundTransactionData.status === 'SUCCESS' ? outboundTransactionData.tracking_number : 'Tracking generation failed - check Shippo dashboard',
      rate: outboundRate.amount,
      service: `${outboundRate.servicelevel.name} (${outboundRate.provider})`,
      status: outboundTransactionData.status,
      transaction_id: outboundTransactionData.object_id,
    };

    const returnLabel = {
      label_url: returnTransactionData.status === 'SUCCESS' ? returnTransactionData.label_url : 'Label generation failed - check Shippo dashboard',
      tracking_number: returnTransactionData.status === 'SUCCESS' ? returnTransactionData.tracking_number : 'Tracking generation failed - check Shippo dashboard',
      rate: returnRate.amount,
      service: `${returnRate.servicelevel.name} (${returnRate.provider})`,
      status: returnTransactionData.status,
      transaction_id: returnTransactionData.object_id,
    };

    // Send emails asynchronously to avoid timeout
    const sendEmails = async () => {
      try {
        // Send detailed shipping label email to warehouse staff
        const warehouseEmailContent = `New Order Shipping Labels - ${order_id}

Customer: ${customer_name}
Address: ${to_address.street1}, ${to_address.city}, ${to_address.state} ${to_address.zip}

Outbound Label: ${outboundLabel.label_url}
Outbound Tracking: ${outboundLabel.tracking_number}
Outbound Service: ${outboundLabel.service}
Outbound Rate: $${outboundLabel.rate}

Return Label: ${returnLabel.label_url}
Return Tracking: ${returnLabel.tracking_number}
Return Service: ${returnLabel.service}
Return Rate: $${returnLabel.rate}

Order ID: ${order_id}`;

        const warehouseMailOptions = {
          from: process.env.EMAIL_USER || 'noreply@dissonant.com',
          to: 'dissonant.helpdesk@gmail.com',
          subject: `Shipping Labels for Order ${order_id}`,
          text: warehouseEmailContent,
        };

        await transporter.sendMail(warehouseMailOptions);
        console.log(`Warehouse shipping label email sent for order ${order_id}`);
      } catch (emailError) {
        console.error('Failed to send warehouse shipping label email:', emailError);
      }

      // Send tracking information only to customer
      if (customer_email) {
        try {
          const customerEmailContent = `Your Order Tracking Information - ${order_id}

Hi ${customer_name},

Your order has been processed and shipping labels have been created.

Outbound Tracking Number: ${outboundLabel.tracking_number}
Return Tracking Number: ${returnLabel.tracking_number}

You can track your package using these tracking numbers on the USPS website.

Thank you for your order!

Order ID: ${order_id}`;

          const customerMailOptions = {
            from: process.env.EMAIL_USER || 'noreply@dissonant.com',
            to: customer_email,
            subject: `Order Tracking Information - ${order_id}`,
            text: customerEmailContent,
          };

          await transporter.sendMail(customerMailOptions);
          console.log(`Customer tracking email sent for order ${order_id} to ${customer_email}`);
        } catch (emailError) {
          console.error('Failed to send customer tracking email:', emailError);
        }
      }
    };

    // Start email sending in background (don't await to avoid timeout)
    sendEmails().catch(err => {
      console.error('Background email sending failed:', err);
    });

    return res.json({
      success: true,
      order_id,
      message: 'Real shipping labels created and emails sent successfully',
      outbound_label: outboundLabel,
      return_label: returnLabel,
    });

  } catch (err) {
    console.error('Shipping label creation error', err);
    return res.status(500).json({ error: `Internal error creating shipping labels: ${err.message}` });
  }
});

// Webhook endpoint for Shippo tracking updates
app.post('/shippo-webhook', async (req, res) => {
  try {
    const { event, data } = req.body;
    
    console.log('Received Shippo webhook:', event, data?.object_id);
    
    if (event === 'track_updated' && data?.tracking_number) {
      await updateOrderStatusFromTracking(data.tracking_number, data.tracking_status);
    }
    
    res.json({ success: true });
  } catch (err) {
    console.error('Webhook processing error:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Manual endpoint to check and update order status
app.post('/check-order-status', async (req, res) => {
  try {
    const { tracking_number, order_id } = req.body;
    
    if (!tracking_number) {
      return res.status(400).json({ error: 'Tracking number required' });
    }
    
    console.log(`Checking status for tracking: ${tracking_number}`);
    
    // Get tracking info from Shippo
    const trackingResponse = await fetch(`https://api.goshippo.com/tracks/${tracking_number}/`, {
      headers: {
        'Authorization': `ShippoToken ${process.env.SHIPPO_TOKEN}`,
      },
    });
    
    if (!trackingResponse.ok) {
      const errorData = await trackingResponse.json();
      console.error('Failed to get tracking info:', errorData);
      return res.status(400).json({ error: 'Failed to get tracking info' });
    }
    
    const trackingData = await trackingResponse.json();
    console.log('Tracking data received:', trackingData.tracking_status);
    
    // Update order status in Firestore
    const updatedStatus = await updateOrderStatusFromTracking(tracking_number, trackingData.tracking_status, order_id);
    
    res.json({
      success: true,
      tracking_number,
      status: trackingData.tracking_status,
      updated: updatedStatus
    });
    
  } catch (err) {
    console.error('Order status check error:', err);
    res.status(500).json({ error: `Status check failed: ${err.message}` });
  }
});

// Function to update order status in Firestore based on tracking
async function updateOrderStatusFromTracking(trackingNumber, trackingStatus, orderId = null) {
  try {
    console.log(`Updating order status for tracking ${trackingNumber}: ${trackingStatus}`);
    
    // Map Shippo tracking status to our order status
    let orderStatus = 'unknown';
    let statusDescription = '';
    
    switch (trackingStatus?.state?.toLowerCase()) {
      case 'unknown':
        orderStatus = 'labelCreated';
        statusDescription = 'Shipping label created';
        break;
      case 'delivered':
        orderStatus = 'delivered';
        statusDescription = 'Package delivered';
        break;
      case 'transit':
        orderStatus = 'sent';
        statusDescription = 'Package in transit';
        break;
      case 'returned':
        orderStatus = 'returned';
        statusDescription = 'Package returned';
        break;
      case 'failure':
        orderStatus = 'deliveryFailed';
        statusDescription = 'Delivery failed';
        break;
      default:
        orderStatus = 'labelCreated';
        statusDescription = 'Shipping label created';
    }
    
    let updatedOrders = [];
    
    // If we have an order ID, update that specific order
    if (orderId) {
      try {
        const orderRef = db.collection('orders').doc(orderId);
        await orderRef.update({
          status: orderStatus,
          statusDescription: statusDescription,
          updatedAt: new Date().toISOString(),
          trackingStatus: trackingStatus,
        });
        console.log(`Order ${orderId} status updated to ${orderStatus} in Firestore`);
        updatedOrders.push(orderId);
      } catch (error) {
        console.error(`Failed to update order ${orderId}:`, error);
      }
    }
    
    // Also search for orders with this tracking number and update them
    try {
      const ordersQuery = await db.collection('orders')
        .where('trackingNumber', '==', trackingNumber)
        .get();
      
      if (!ordersQuery.empty) {
        const batch = db.batch();
        ordersQuery.forEach(doc => {
          batch.update(doc.ref, {
            status: orderStatus,
            statusDescription: statusDescription,
            updatedAt: new Date().toISOString(),
            trackingStatus: trackingStatus,
          });
          updatedOrders.push(doc.id);
        });
        await batch.commit();
        console.log(`Updated ${ordersQuery.size} orders with tracking ${trackingNumber}`);
      }
    } catch (error) {
      console.error(`Failed to search orders by tracking number:`, error);
    }
    
    // Send notification email to customer about status change
    if (updatedOrders.length > 0) {
      await sendStatusUpdateEmail(trackingNumber, orderStatus, statusDescription, updatedOrders);
    }
    
    return {
      tracking_number: trackingNumber,
      order_status: orderStatus,
      description: statusDescription,
      updated_orders: updatedOrders,
      timestamp: new Date().toISOString()
    };
    
  } catch (err) {
    console.error('Error updating order status:', err);
    throw err;
  }
}

// Function to send status update emails to customers
async function sendStatusUpdateEmail(trackingNumber, orderStatus, statusDescription, orderIds) {
  try {
    // Get customer information from the first updated order
    const orderDoc = await db.collection('orders').doc(orderIds[0]).get();
    if (!orderDoc.exists) {
      console.log('Order not found for email notification');
      return;
    }
    
    const orderData = orderDoc.data();
    const customerEmail = orderData.customerEmail || orderData.email;
    const customerName = orderData.customerName || orderData.name || 'Valued Customer';
    
    if (!customerEmail) {
      console.log('No customer email found for status update notification');
      return;
    }
    
    // Create status update email content
    const emailContent = `Order Status Update

Hi ${customerName},

Your order status has been updated:

Status: ${statusDescription}
Tracking Number: ${trackingNumber}
Order ID(s): ${orderIds.join(', ')}

You can track your package using the tracking number on the USPS website.

Thank you for choosing Dissonant!

Best regards,
The Dissonant Team`;

    const mailOptions = {
      from: process.env.EMAIL_USER || 'noreply@dissonant.com',
      to: customerEmail,
      subject: `Order Status Update - ${statusDescription}`,
      text: emailContent,
    };

    await transporter.sendMail(mailOptions);
    console.log(`Status update email sent to ${customerEmail} for tracking ${trackingNumber}`);
    
  } catch (emailError) {
    console.error('Failed to send status update email:', emailError);
  }
}

module.exports.handler = serverless(app);